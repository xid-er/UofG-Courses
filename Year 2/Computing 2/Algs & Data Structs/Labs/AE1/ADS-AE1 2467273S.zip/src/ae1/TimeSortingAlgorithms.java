package ae1;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TimeSortingAlgorithms {
	
	static int[] readArray(String file) {
		Path path = Paths.get(System.getProperty("user.dir"), "num", file);
		try {
			//https://stackoverflow.com/questions/32838831/convert-liststring-to-int/32838964
			int[] a = Files.readAllLines(path).stream().mapToInt(Integer::parseInt).toArray();
			return a;
		} catch(IOException ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	static void time() {
		File folder = new File("./num");
		for(String file : folder.list()) {
			System.out.println("----------------------------------");
			System.out.println("Time taken to sort " + file +":");
			
			int[] a = readArray(file);
			int n = a.length;
			AE1 timed = new AE1(a);
			
			long time1, time2, timeTaken;
			
			if (n <= 1000) {
				time1 = System.nanoTime();
				timed.quickSortA(0, n-1);
				time2 = System.nanoTime();
				timeTaken = time2 - time1;
				System.out.println("QuickSort (A): " + timeTaken + " ns");
			} else {
				time1 = System.currentTimeMillis();
				timed.quickSortA(0, n-1);
				time2 = System.currentTimeMillis();
				timeTaken = time2 - time1;
				System.out.println("QuickSort (A): " + timeTaken + " ms");
			}
			
			
			
			int[] b = readArray(file);
			timed.setArray(b);
			if (n <= 1000) {
				time1 = System.nanoTime();
				timed.quickSortB(0, n-1, 20);
				time2 = System.nanoTime();
				timeTaken = time2 - time1;
				System.out.println("Hybrid QuickSort (B): " + timeTaken + " ns");
			} else {
				time1 = System.currentTimeMillis();
				timed.quickSortB(0, n-1, 20);
				time2 = System.currentTimeMillis();
				timeTaken = time2 - time1;
				System.out.println("Hybrid QuickSort (B): " + timeTaken + " ms");
			}
			
			int[] c = readArray(file);
			timed.setArray(c);
			if (n <= 1000) {
				time1 = System.nanoTime();
				timed.quickSortC(0, n-1);
				time2 = System.nanoTime();
				timeTaken = time2 - time1;
				System.out.println("M3 QuickSort (C): " + timeTaken + " ns");
			} else {
				time1 = System.currentTimeMillis();
				timed.quickSortC(0, n-1);
				time2 = System.currentTimeMillis();
				timeTaken = time2 - time1;
				System.out.println("M3 QuickSort (C): " + timeTaken + " ms");
			}
			
			int[] d = readArray(file);
			timed.setArray(d);
			if (n <= 1000) {
				time1 = System.nanoTime();
				timed.quickSortD(0, n-1);
				time2 = System.nanoTime();
				timeTaken = time2 - time1;
				System.out.println("3-way QuickSort (D): " + timeTaken + " ns");
			} else {
				time1 = System.currentTimeMillis();
				timed.quickSortD(0, n-1);
				time2 = System.currentTimeMillis();
				timeTaken = time2 - time1;
				System.out.println("3-way QuickSort (D): " + timeTaken + " ms");
			}
			
			/*
			int[] i = readArray(file);
			timed.setArray(i);
			if (n <= 1000) {
				time1 = System.nanoTime();
				timed.insertionSort();
				time2 = System.nanoTime();
				timeTaken = time2 - time1;
				System.out.println("Insertion Sort: " + timeTaken + " ns");
			} else {
				time1 = System.currentTimeMillis();
				timed.insertionSort();
				time2 = System.currentTimeMillis();
				timeTaken = time2 - time1;
				System.out.println("Insertion Sort: " + timeTaken + " ms");
			}
			*/
			int[] m = readArray(file);
			timed.setArray(m);
			if (n <= 1000) {
				time1 = System.nanoTime();
				timed.mergeSort(0, n-1);
				time2 = System.nanoTime();
				timeTaken = time2 - time1;
				System.out.println("Merge Sort: " + timeTaken + " ns");
			} else {
				time1 = System.currentTimeMillis();
				timed.mergeSort(0, n-1);
				time2 = System.currentTimeMillis();
				timeTaken = time2 - time1;
				System.out.println("Merge Sort: " + timeTaken + " ms");
			}
		}
	}
	
	public static void main(String[] args) {
		time();
	}
}
