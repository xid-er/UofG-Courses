package ae1;

import java.util.Arrays;

public class AE1 {
	
	private int[] a;
	
	public AE1(int[] a) {
		this.a = a;
	}
	
	public int[] getArray() {
		return this.a;
	}
	
	public void setArray(int[] a) {
		this.a = a;
	}
	
	public boolean isSorted() {
		int n = a.length;
		for(int i = 0; i < n-1; i++) {
			if (a[i] > a[i+1]) {
				return false;
			}
		}
		return true;
	}
	
	public void insertionSort() {
		int n = a.length;
		for(int i = 1; i < n; i++) {
			int key = a[i];
			int j = i - 1;
			while(j >= 0 && a[j] > key) {
				a[j+1] = a[j];
				j--;
			}
			a[j+1] = key;
		}
	}
	
	public void merge(int p, int q, int r){
		int n1 = q - p + 1;
		int n2 = r - q;
		int[] L = new int[n1 + 1];
		int[] R = new int[n2 + 1];
		
		for (int i=0; i<n1; i++)
			L[i] = a[p + i];
		for (int j=0; j<n2; j++)
			R[j] = a[q + 1+ j];
		L[n1] = Integer.MAX_VALUE;
		R[n2] = Integer.MAX_VALUE;
		
		int i = 0;
		int j = 0;
		for (int k = p; k <= r; k++){
			if(L[i] <= R[j]){
				a[k] = L[i];
				i++;
			} else {
				a[k] = R[j];
				j++;
			}
		}
	}
	
	public void mergeSort(int p, int r){
		if (p < r){
			int q = (p+r)/2;
			mergeSort(p, q);
			mergeSort(q+1, r);
			merge(p, q, r);
		}
	}
	
	public void swap(int x, int y) {
		int temp = a[x];
		a[x] = a[y];
		a[y] = temp;
	}

	// Pivot - last element
	public int partition(int p, int r) {
		int x = a[r];
		int i = p - 1;
		for (int j = p; j <= r - 1; j++) {
			if (a[j] <= x) {
				i++;
				swap(i, j);
			}
		}
		swap(i+1, r);
		return i + 1;
	}
	
	// Pivot - median of three
	public int partition(int p, int q, int r) {
		if(a[q] < a[p]) swap(p, q);
		if(a[r] < a[p]) swap(p, r);
		if(a[q] < a[r]) swap(q, r);
		int x = a[r];
		
		int i = p - 1;
		for (int j = p; j <= r - 1; j++) {
			if (a[j] <= x) {
				i++;
				swap(i, j);
			}
		}
		swap(i+1, r);
		return i + 1;
	}
	
	// Three sections - lower than, equal to, and higher than pivot	
	public int[] partitionThree(int p, int r) {
		int less = p;
		int greater = r;
		int x = a[r];
		
		int i = p;
		while (i <= greater) {
			if (a[i] < x) {
				swap(less, i);
				less++;
				i++;
			}
			else if (a[i] > x) {
				swap(i, greater);
				greater--;
			} else {
				i++;
			}
		}
		
		return new int[] {less, greater};
	}
	
	public void quickSortA(int p, int r) {
		if (p < r) {
			int q = partition(p, r);
			quickSortA(p, q-1);
			quickSortA(q+1, r);
		}
	}
	
	public void quickSortBSmall(int p, int r, int k) {
		if (p < r) {
			if (r <= p + k - 1) {
				return;
			}
			int q = partition(p, r);
			quickSortBSmall(p, q-1, k);
			quickSortBSmall(q+1, r, k);
		}
	}
	
	public void quickSortB(int p, int r, int k) {
		quickSortBSmall(p, r, k);
		insertionSort();
	}
	
	public void quickSortC(int p, int r) {
		if (p < r) {
			int q = partition(p, (int)((p+r)/2), r);
			quickSortC(p, q-1);
			quickSortC(q+1, r);
		}
	}
	
	public void quickSortD(int p, int r) {
		if (p < r) {
			int[] ix = partitionThree(p, r);
			quickSortD(p, ix[0] - 1);
			quickSortD(ix[1] + 1, r);;
		}
	}
	
	public int[] normalInput(int n) {
		int[] res = new int[n];
		for(int i = 0; i < n; i++) {
			res[i] = i + 1;
		}
		return res;
	}
	
	public int[] reverseInput(int n) {
		int[] res = new int[n];
		for(int i = n-1; i >= 0; i--) {
			res[i] = n-1-i;
		}
		return res;
	}
	
	public int[] pathInt(int n) {
		int[] res = new int[n];
		int[] norm = normalInput(n);
		int half = n / 2;
		for (int i = 1; i <= half; i++) {
			if ((i % 2) == 1) {
				res[i-1] = norm[i-1];
				res[i] = norm[half+i-1];
			}
			res[half+i-1] = norm[(i*2)-1];
		}
		return res;
	}
	
	public static void main(String[] args) {
		int[] a = TimeSortingAlgorithms.readArray("intBig.txt");
		//int[] b = {3,1,6,5,2,4};
		AE1 test = new AE1(a);
		int n = a.length;
		//test.insertionSort();
		//test.mergeSort(0, n-1);
		//test.quickSortA(0, n-1);
		//test.quickSortB(0, n-1, 20);
		//test.quickSortC(0, n-1);
		//test.quickSortD(0, n-1);
		//System.out.println(Arrays.toString(test.getArray()));
		
		/*
		long time1 = System.currentTimeMillis();
		test.quickSortD(0, n-1);
		long time2 = System.currentTimeMillis();
		long timeTaken = time2 - time1;
		System.out.println("QuickSort (D): " + timeTaken + " ms");
		//System.out.println(Arrays.toString(test.getArray()));
		System.out.println(test.isSorted());
		*/
		
		//System.out.println(Arrays.toString(test.pathologicalInput(100)));
		
		
		/*
		//test.setArray(test.normalInput(50000));
		test.setArray(TimeSortingAlgorithms.readArray("int500k.txt"));
		n = test.getArray().length;
		long time1 = System.currentTimeMillis();
		test.quickSortC(0, n-1);
		long time2 = System.currentTimeMillis();
		long timeTaken = time2 - time1;
		System.out.println("M3 QuickSort (normal): " + timeTaken + " ms");
		
		//test.setArray(test.reverseInput(50000));
		test.setArray(TimeSortingAlgorithms.readArray("int500k.txt"));
		n = test.getArray().length;
		time1 = System.currentTimeMillis();
		test.quickSortC(0, n-1);
		time2 = System.currentTimeMillis();
		timeTaken = time2 - time1;
		System.out.println("M3 QuickSort (reverse): " + timeTaken + " ms");
		
		test.setArray(test.pathInt(500000));
		n = test.getArray().length;
		time1 = System.currentTimeMillis();
		test.quickSortC(0, n-1);
		time2 = System.currentTimeMillis();
		timeTaken = time2 - time1;
		System.out.println("M3 QuickSort (pathological): " + timeTaken + " ms");
		*/
		
		
		test.setArray(test.pathInt(20));
		System.out.println(Arrays.toString(test.getArray()));
		n = test.getArray().length;
		System.out.println("Sorted: " + test.isSorted());
		test.quickSortC(0, n-1);
		System.out.println("Sorted: " + test.isSorted());
	}

}
