package vehicle.types;

public class Motorcycle extends MotorVehicle {
	
	public Motorcycle(String name){
		super(name);
		setNowheels(2);
	}


}
