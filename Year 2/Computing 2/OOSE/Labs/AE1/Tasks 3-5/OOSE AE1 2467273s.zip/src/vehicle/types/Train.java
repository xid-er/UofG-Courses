package vehicle.types;

public class Train extends RailedVehicle {
	
	public Train(String name, int nocarriages) {
		super(name);
		setNocarriages(nocarriages);
	}
}
