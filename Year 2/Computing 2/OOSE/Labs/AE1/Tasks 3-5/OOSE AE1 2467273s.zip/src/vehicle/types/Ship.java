package vehicle.types;

public class Ship extends Watercraft {

	public Ship(String name){
		super(name);
	}
}
