#ifndef _I_32_H_
#define _I_32_H_

#include "i_55.h"
#include "i_50.h"

#endif /* _I_32_H_ */
