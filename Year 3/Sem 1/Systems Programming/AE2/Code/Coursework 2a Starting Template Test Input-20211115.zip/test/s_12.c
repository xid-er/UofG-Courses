#include "i_10.h"
#include "i_33.h"
#include <string.h>
#include <pthread.h>
