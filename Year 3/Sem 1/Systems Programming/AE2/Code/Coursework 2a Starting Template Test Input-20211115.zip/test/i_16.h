#ifndef _I_16_H_
#define _I_16_H_

#include <netinet/in.h>	/* defines in_addr_t */
#include "i_51.h"

#endif /* _I_16_H_ */
