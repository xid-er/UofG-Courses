#include  <stdio.h>
#include <stdlib.h>
#include <string.h>
#include  <ctype.h>
#include "i_40.h"
